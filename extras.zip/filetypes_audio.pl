package filetypes;

%filetypes=
(
	mp3 => 'icons/audio-mp3.png',
	ogg => 'icons/audio-ogg.png',
	aac => 'icons/audio-aac.png',
	m4a => 'icons/audio-aac.png',
	mpc => 'icons/audio-mpc.png',
	mpp => 'icons/audio-mpp.png',
	mod => 'icons/audio-mod.png',
	it => 'icons/audio-it.png',
	xm => 'icons/audio-xm.png',
	fla => 'icons/audio-flac.png',
	flac => 'icons/audio-flac.png'
);

1;
